<?php
session_start();
include("../database/db.php");
include('../function/functions.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4"></div>
            <div class="col-md-4">
                <form action="../admin/login_user.php" method="POST">
                <p><a href="../index.php" class="btn"><strong>home</strong></a><hr></p>

                    <h2 class="text-center">Login</h2>
                    <div class="form-group">
                        <label for="email">User Email:</label>
                        <input type="email" class="form-control" id="email" name="name" placeholder="Type Your Email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Type Your Password" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Login</button>
                    <p class="text-center"><hr> Don't have an account? <a href="registration.php"><strong>Sign up</strong></a></p>
                </form>
            </div>
            <div class="col-md-4"></div>
        </div>
    </div>
</body>
</html>