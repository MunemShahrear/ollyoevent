<?php
session_start();
include("../database/db.php");
include('../function/functions.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User Registration</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4"></div>
            <div class="col-md-4">
                <form name="user_reg_form" action="../reg/reg_Confirm.php" method="post">
                    <h2 class="text-center">User Registration</h2>
                    <div class="form-group">
                        <label for="txt_user_UserName">User Name:</label>
                        <input type="text" class="form-control" id="txt_user_UserName" name="txt_user_UserName" placeholder="e.g: Himel" required>
                    </div>
                    <div class="form-group">
                        <label for="txt_user_UserEmail">User Email:</label>
                        <input type="email" class="form-control" id="txt_user_UserEmail" name="txt_user_UserEmail" placeholder="mail@shahrear.me" required>
                    </div>
                    <div class="form-group">
                        <label for="txt_user_UserPassword">User Password:</label>
                        <input type="password" class="form-control" id="txt_user_UserPassword" name="txt_user_UserPassword" placeholder="Type Your Password" required>
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="termsCheckbox" required>
                        <label class="form-check-label" for="termsCheckbox">I AGREE WITH THE TERMS AND CONDITIONS</label>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block mt-3">Register</button>
                    <p><hr> Have an account ?<br> <a href="login.php" class="btn"><strong>Back to Login</strong></a></p>
                </form>
            </div>
            <div class="col-md-4"></div>
        </div>
    </div>
</body>
</html>
