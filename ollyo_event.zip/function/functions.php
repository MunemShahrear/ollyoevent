<?php


$db=mysqli_connect("localhost", "cnzixezfln_event_management", "Himel625646@#", "cnzixezfln_event_management");




function getEvent()
{
    global $db;
    if (!isset($_GET['cat'])&& !isset($_GET['brandy'])) {
        $get_products = "SELECT * FROM events LIMIT 0,12";
        $run_products = mysqli_query($db, $get_products);
        while ($row_products = mysqli_fetch_array($run_products)) {
            $pro_id = $row_products['id'];
            $pro_title = $row_products['title'];
            $pro_cat = $row_products['cat_id'];
            $pro_desc = $row_products['description'];
            $pro_price = $row_products['price'];
            $pro_image = $row_products['banner'];
            $event_venue = $row_products['event_venue'];
            $event_time = $row_products['event_time'];
            $event_date = $row_products['event_date'];
            $stock = $row_products['seats'];

            $formatted_date = date("j F Y", strtotime($event_date)); 
            $formatted_time = date("g A", strtotime($event_time));
            if($stock>0){
               
                echo "<a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
            <div class='col-md-4'>
                <div class='card mb-3 shadow-sm product-card' style='padding=20px; margin=50px;'>
                    <a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                        <img src='admin/event_images/$pro_image' class='bd-placeholder-img card-img-top' width ='100%' alt='$pro_title'>
                    </a>
                    <div class='card-body'>
                        <a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                            <h3 class='card-title'>$pro_title</h3>
                        </a>
                   

<p class='card-text'>Date: $formatted_date</p>
<p class='card-text'>Time: $formatted_time</p>
   <p class='card-text'>Venue: $event_venue</p>
                        <p class='card-text'>Price: BDT $pro_price</p>
                        <div class='d-flex justify-content-between align-items-center'>
                            <div class='btn-group'>
                                <form action='' class='form-submit'>
                                    <input type='hidden' class='pid' value='$pro_id'>
                                    <input type='hidden' class='pname' value='$pro_title'>
                                    <input type='hidden' class='pprice' value='$pro_price'>
                                    <input type='hidden' class='pimage' value='$pro_image'>
                                    <p>Seats: $stock Person</p>
                                    <button class='btn btn-sm btn-outline-secondary bookTicketBtn'>
                                                <i style='color:#3f6b3d' class='fa fa-ticket'></i> Book Now
                                            </button>
                                    </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            ";
            }
            else{

                
                echo "<a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
            <div class='col-md-4'>
                <div class='card mb-3 shadow-sm product-card' style='padding=20px; margin=50px;'>
                    <a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                        <img src='admin/event_images/$pro_image' class='bd-placeholder-img card-img-top'width ='100%' alt='$pro_title'>
                    </a>
                    <div class='card-body'>
                        <a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                            <h3 class='card-title'>$pro_title</h3>
                        </a>
                        
                        <div class='d-flex justify-content-between align-items-center'>
                            <div class='btn-group'>
                                     

<p class='card-text'>Date: $formatted_date</p>
<p class='card-text'>Time: $formatted_time</p>
   <p class='card-text'>Venue: $event_venue</p>
                        <p class='card-text'>Price: BDT $pro_price</p>
                                <form action='' class='form-submit'>
                                    <input type='hidden' class='pid' value='$pro_id'>
                                    <input type='hidden' class='pname' value='$pro_title'>
                                  
                                    <input type='hidden' class='pimage' value='$pro_image'>
                                    <p>Item: 0 pcs</p>
                                     <button disabled class='btn btn-sm btn-outline-secondary'>
                                            <i style='color: #fc0335;' class='fa fa-times-circle'></i> Sold Out
                                        </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            ";
            }

            
        }
    }
}


function getdel() {
    global $db;
    if (!isset($_GET['cat'])&& !isset($_GET['brandy'])) {
        $get_products = "SELECT * FROM events";
        $run_products = mysqli_query($db, $get_products);
        while ($row_products = mysqli_fetch_array($run_products)) {
            $pro_id = $row_products['id'];
            $pro_title = $row_products['title'];
            $pro_cat = $row_products['cat_id'];
            $pro_desc = $row_products['description'];
            $pro_price = $row_products['price'];
            $pro_image = $row_products['banner'];

            echo "
            <div class='col-md-4 mb-4'>
                <div class='card'>
                    <img src='../admin/event_images/$pro_image' class='card-img-top' alt='$pro_title'>
                    <div class='card-body'>
                        <h5 class='card-title'>$pro_title</h5>
                        <p class='card-text'>$pro_desc</p>
                        <p class='card-text'>Price: $pro_price</p>
                        <a href='../delete_user.php?pro_id=$pro_id' class='btn btn-danger'>Delete</a>
                    </div>
                </div>
            </div>";
        }
    }
}


function getupdate(){
	
	global $db;
	if(!isset($_GET['cat'])&& !isset($_GET['brandy'])){
		$get_products="select * from events";
		$run_products=mysqli_query($db,$get_products);
		while ($row_products=mysqli_fetch_array($run_products)){
			$pro_id=$row_products['id'];
			$pro_title=$row_products['title'];
			$pro_cat=$row_products['cat_id'];
			$pro_desc=$row_products['description'];
			$pro_price=$row_products['price'];
			$pro_image=$row_products['banner'];
			
			echo "
			<a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
            <div class='col-md-4'>
                <div class='card mb-3 shadow-sm product-card' style='padding=20px; margin=50px;'>
                    <a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                        <img src='../admin/event_images/$pro_image' class='bd-placeholder-img card-img-top' height='50%' width ='70%' alt='$pro_title'>
                    </a>
                    <div class='card-body'>
                        <a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                            <h3 class='card-title'>$pro_title</h3>
                        </a>
                        <p class='card-text'>Price: A$ $pro_price</p>
                        <div class='d-flex justify-content-between align-items-center'>
                            <div class='btn-group'>
                                
									<a class='btn btn-sm btn-outline-secondary ' href='../update_details.php?pro_id=$pro_id' class='btn btn-primary'>Update</a>
                                    
                            
                            </div>
                        </div>
                    </div>
                </div>
            </div>	

			";
		}
	}
}

	function getRelPro(){
	
	global $db;
	if (isset($_GET['pro_id']))
		{
	 $pro_id=$_GET['pro_id'];
		$get_products="select * from events where cat_id=(select cat_id from events where id=$pro_id )order by rand() LIMIT 0,3";
		$run_products=mysqli_query($db,$get_products);
		while ($row_products=mysqli_fetch_array($run_products)){
			$pro_id=$row_products['id'];
		$pro_title=$row_products['title'];
		$pro_cat=$row_products['cat_id'];
		$pro_desc=$row_products['description'];
		$pro_price=$row_products['price'];
		$pro_image=$row_products['banner'];
        $stock = $row_products['seats'];
        if($stock>0){
           
            echo "<a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
        <div class='col-md-3'>
            <div class='card mb-3 shadow-sm product-card' style='padding=20px; margin=50px;'>
                <a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                    <img src='admin/event_images/$pro_image' class='bd-placeholder-img card-img-top' height='50%' width ='70%' alt='$pro_title'>
                </a>
                <div class='card-body'>
                    <a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                        <h3 class='card-title'>$pro_title</h3>
                    </a>
                    <p class='card-text'>Price: A$ $pro_price</p>
                    <div class='d-flex justify-content-between align-items-center'>
                        <div class='btn-group'>
                            <form action='' class='form-submit'>
                                <input type='hidden' class='pid' value='$pro_id'>
                                <input type='hidden' class='pname' value='$pro_title'>
                                <input type='hidden' class='pprice' value='$pro_price'>
                                <input type='hidden' class='pimage' value='$pro_image'>
                                <p>Item: $stock pcs</p>
                                <button class='btn btn-sm btn-outline-secondary addItemBtn'><i style='color:#3f6b3d' class='fa fa-ticket'></i>Book Now</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        ";
        }
        else{

            
            echo "<a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
        <div class='col-md-3'>
            <div class='card mb-3 shadow-sm product-card' style='padding=20px; margin=50px;'>
                <a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                    <img src='admin/event_images/$pro_image' class='bd-placeholder-img card-img-top' height='50%' width ='70%' alt='$pro_title'>
                </a>
                <div class='card-body'>
                    <a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                        <h3 class='card-title'>$pro_title</h3>
                    </a>
                    <p class='card-text'>Price: A$ $pro_price</p>
                    <div class='d-flex justify-content-between align-items-center'>
                        <div class='btn-group'>
                            <form action='' class='form-submit'>
                                <input type='hidden' class='pid' value='$pro_id'>
                                <input type='hidden' class='pname' value='$pro_title'>
                                <input type='hidden' class='pprice' value='$pro_price'>
                                <input type='hidden' class='pimage' value='$pro_image'>
                                <p>Item: 0 pcs</p>
                                <button  Disabled class='btn btn-sm btn-outline-secondary '><i style='color: #fc0335;' class='fa fa-cart-plus'></i>Out Of Stock</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        ";
        }

    
    
    }
	
	
	
	}
	}
	
	function getCatPro(){
	
	global $db;
	if(isset($_GET['cat'])){
		$cat_id= $_GET['cat'];
		
		$get_cat_pro="select * from events where cat_id='$cat_id'";
		$run_cat_pro=mysqli_query($db,$get_cat_pro);
		$count=mysqli_num_rows($run_cat_pro);
		if($count==0){
			echo"<h2>no products available in this category</h2>";
			}
		while ($row_cat_pro=mysqli_fetch_array($run_cat_pro)){
			$pro_id=$row_cat_pro['id'];
		$pro_title=$row_cat_pro['title'];
		$pro_cat=$row_cat_pro['cat_id'];
		$pro_desc=$row_cat_pro['description'];
		$pro_price=$row_cat_pro['price'];
		$pro_image=$row_cat_pro['banner'];
        $stock = $row_cat_pro['seats'];
        if($stock>0){
           
            echo "<a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
        <div class='col-md-3'>
            <div class='card mb-3 shadow-sm product-card' style='padding=20px; margin=50px;'>
                <a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                    <img src='admin/event_images/$pro_image' class='bd-placeholder-img card-img-top'width ='100%' alt='$pro_title'>
                </a>
                <div class='card-body'>
                    <a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                        <h3 class='card-title'>$pro_title</h3>
                    </a>
                    <p class='card-text'>Price: A$ $pro_price</p>
                    <div class='d-flex justify-content-between align-items-center'>
                        <div class='btn-group'>
                            <form action='' class='form-submit'>
                                <input type='hidden' class='pid' value='$pro_id'>
                                <input type='hidden' class='pname' value='$pro_title'>
                                <input type='hidden' class='pprice' value='$pro_price'>
                                <input type='hidden' class='pimage' value='$pro_image'>
                                <p>Item: $stock pcs</p>
                                <button class='btn btn-sm btn-outline-secondary addItemBtn'><i style='color:#3f6b3d' class='fa fa-ticket'></i>Book Now</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        ";
        }
        else{

            
            echo "<a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
        <div class='col-md-3'>
            <div class='card mb-3 shadow-sm product-card' style='padding=20px; margin=50px;'>
                <a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                    <img src='admin/event_images/$pro_image' class='bd-placeholder-img card-img-top' height='50%' width ='70%' alt='$pro_title'>
                </a>
                <div class='card-body'>
                    <a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                        <h3 class='card-title'>$pro_title</h3>
                    </a>
                    <p class='card-text'>Price: A$ $pro_price</p>
                    <div class='d-flex justify-content-between align-items-center'>
                        <div class='btn-group'>
                            <form action='' class='form-submit'>
                                <input type='hidden' class='pid' value='$pro_id'>
                                <input type='hidden' class='pname' value='$pro_title'>
                                <input type='hidden' class='pprice' value='$pro_price'>
                                <input type='hidden' class='pimage' value='$pro_image'>
                                <p>Item: 0 pcs</p>
                                <button  Disabled class='btn btn-sm btn-outline-secondary '><i style='color: #fc0335;' class='fa fa-cart-plus'></i>Sold Out</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        ";
        }

	
    
    
    }
	}
	
	
	}
	
	
	
	function getCats(){
		global $db;
			$get_cats="select * from categories";
			$run_cats=mysqli_query($db,$get_cats);
			while ($row_cats=mysqli_fetch_array($run_cats)){
				$cat_id=$row_cats['cat_id'];
				$cat_title=$row_cats['cat_title'];
			
   			   echo "<li><a href='index.php?cat=$cat_id'>$cat_title</a></li>";}
			}
     function getBrands(){
                global $db;
                    $get_brands="select * from brand";
                    $run_brands=mysqli_query($db,$get_brands);
                    while ($row_brands=mysqli_fetch_array($run_brands)){
                        $brand_id=$row_brands['brand_id'];
                        $brand_name=$row_brands['brand_name'];
                    
                          echo "<li><a href='index.php?brandy=$brand_id'>$brand_name</a></li>";}
                    }
                    function getBrandPro(){
	
                        global $db;
                        if(isset($_GET['brandy'])){
                            $brand_id= $_GET['brandy'];
                            
                            $get_brand_pro="select * from products where brand_id='$brand_id'";
                            $run_brand_pro=mysqli_query($db,$get_brand_pro);
                            $count=mysqli_num_rows($run_brand_pro);
                            if($count==0){
                                echo"<h2>no products available in this category</h2>";
                                }
                            while ($row_cat_pro=mysqli_fetch_array($run_brand_pro)){
                                $pro_id=$row_cat_pro['product_id'];
                            $pro_title=$row_cat_pro['title'];
                            $pro_cat=$row_cat_pro['cat_id'];
                            $pro_desc=$row_cat_pro['description'];
                            $pro_price=$row_cat_pro['price'];
                            $pro_image=$row_cat_pro['img1'];
                            $stock = $row_cat_pro['stock'];
                            if($stock>0){
                               
                                echo "<a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                            <div class='col-md-3'>
                                <div class='card mb-3 shadow-sm product-card' style='padding=20px; margin=50px;'>
                                    <a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                                        <img src='admin/product_image/$pro_image' class='bd-placeholder-img card-img-top' height='50%' width ='70%' alt='$pro_title'>
                                    </a>
                                    <div class='card-body'>
                                        <a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                                            <h3 class='card-title'>$pro_title</h3>
                                        </a>
                                        <p class='card-text'>Price: A$ $pro_price</p>
                                        <div class='d-flex justify-content-between align-items-center'>
                                            <div class='btn-group'>
                                                <form action='' class='form-submit'>
                                                    <input type='hidden' class='pid' value='$pro_id'>
                                                    <input type='hidden' class='pname' value='$pro_title'>
                                                    <input type='hidden' class='pprice' value='$pro_price'>
                                                    <input type='hidden' class='pimage' value='$pro_image'>
                                                    <p>Item: $stock pcs</p>
                                                    <button class='btn btn-sm btn-outline-secondary addItemBtn'><i style='color:#3f6b3d' class='fa fa-cart-plus'></i>Rent Now</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            ";
                            }
                            else{
                    
                                
                                echo "<a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                            <div class='col-md-3'>
                                <div class='card mb-3 shadow-sm product-card' style='padding=20px; margin=50px;'>
                                    <a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                                        <img src='admin/product_image/$pro_image' class='bd-placeholder-img card-img-top' height='50%' width ='70%' alt='$pro_title'>
                                    </a>
                                    <div class='card-body'>
                                        <a style='color:#3d3d3d' href='details.php?pro_id=$pro_id'>
                                            <h3 class='card-title'>$pro_title</h3>
                                        </a>
                                        <p class='card-text'>Price: A$ $pro_price</p>
                                        <div class='d-flex justify-content-between align-items-center'>
                                            <div class='btn-group'>
                                                <form action='' class='form-submit'>
                                                    <input type='hidden' class='pid' value='$pro_id'>
                                                    <input type='hidden' class='pname' value='$pro_title'>
                                                    <input type='hidden' class='pprice' value='$pro_price'>
                                                    <input type='hidden' class='pimage' value='$pro_image'>
                                                    <p>Item: 0 pcs</p>
                                                    <button  Disabled class='btn btn-sm btn-outline-secondary '><i style='color: #fc0335;' class='fa fa-cart-plus'></i>Out Of Stock</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            ";
                            }
                    
                        
                        
                        
                        }
                        }
                        
                        
                        }		
	function getmethod(){
		global $db;
			$get_cats="select * from method";
			$run_cats=mysqli_query($db,$get_cats);
			while ($row_cats=mysqli_fetch_array($run_cats)){
				$cat_id=$row_cats['method_id'];
				$cat_title=$row_cats['method_title'];
			
   			   echo "<li><a href='payment.php?cat=$cat_id'>$cat_title</a></li>";}
			}
			
	
	
?>