<!-- Header wrapper -->
<link href="stylecart.css" type="text/css" rel="stylesheet" />
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>

<div class="container-fluid bg-dark text-light" style="background:#212121">
    <div class="row">
        <div class="col-12">
            <div class="row">
                <!-- Logo Section -->
                <div class="col-12 col-md-4 text-center"><br>
                    <a href="index.php">
                        <p style="font-family: 'Russo One', sans-serif; font-size: 25px; color: #FFF;">Event Management</p>
                    </a>
                </div>
                <!-- Search Section -->
                <div class="col-12 col-md-4 d-flex align-items-center justify-content-center">
                    <form id="searchForm" style="margin-top: 20px; border-radius:5px;" method="get" action="results.php" enctype="multipart/form-data">
                        <div class="input-group w-100">
                            <input type="text" class="form-control dark-search" name="user_query" id="searchInput" placeholder="search products..." style="width: 100%;">
                            <div id="suggestionsBox" style="position: absolute; background-color: white; z-index: 1000;"></div>
                        </div><br>
                    </form>
                </div>
                <!-- Reservation Button -->
                <div class="col-12 col-md-4 d-flex align-items-center justify-content-center">
                    <a href="cart.php" id="cartToggleBtn" class="btn23 btn-primary">
                        <i class="fa fa-ticket"></i> Reservation
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Navbar -->
<div class="navbar navbar-default align-items-center" style="z-index: 1;">
    <div class="container-fluid">
        <div class="col-12 col-md-12">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse-1">
                <ul class="nav navbar-nav justify-content-center">
                    <li><a href="index.php"><b>Home</b></a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><b>Categories</b> <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <?php getCats(); ?>
                        </ul>
                    </li>
                    <li><a href="rental.php"><b>Manage Reservation</b></a></li>
                    <li><a href="AdmiN.php"><b>Login Admin</b></a></li>
                    <li><a href="login/login.php"><b>User Login</b></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#searchInput').on('keyup', function() {
        var query = $(this).val();
        if (query.length > 2) {
            $.ajax({
                url: 'suggestions.php',
                method: 'GET',
                data: { query: query },
                success: function(data) {
                    $('#suggestionsBox').empty();
                    var suggestions = JSON.parse(data);
                    suggestions.forEach(function(suggestion) {
                        $('#suggestionsBox').append(
                            '<div class="suggestion-item">' + suggestion + '</div>'
                        );
                    });
                    $('.suggestion-item').on('click', function() {
                        $('#searchInput').val($(this).text());
                        $('#searchForm').submit();
                    });
                }
            });
        } else {
            $('#suggestionsBox').empty();
        }
    });
});
</script>

<script>
$(document).ready(function() {
    // Show dropdown on hover for Categories
    $('#hover-dropdown').hover(function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
    }, function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
    });

    // Show dropdown on hover for Login/Register
    $('#hover-dropdown-login').hover(function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
    }, function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
    });
});
</script>

<!-- Additional styles -->
<style>
/* Animation for search input */
@keyframes inputAnimation {
    0% { transform: scaleX(0); }
    100% { transform: scaleX(1); }
}

.input-group {
    animation: inputAnimation 0.5s forwards;
}

.dark-search {
    background-color: #fff;
    color: #000;
    border-color: #f1f1f1;
}

#suggestionsBox {
    border: 1px solid #ccc;
    border-top: none;
    max-height: 150px;
    margin-left: -200px;
    overflow-y: auto;
    border-radius: 5px;
}

.suggestion-item {
    padding: 10px;
    cursor: pointer;
}

.suggestion-item:hover {
    background-color: #93f542;
}

.btn23 {
    background-color: #000000;
    color: white;
    padding: 12px;
    margin: 10px 0;
    border: .5px solid #d73128;
    width: 50%;
    border-radius: 3px;
    cursor: pointer;
    font-size: 14px;
}

.btn23:hover {
    background-color: #0e0e0e;
    border: 1px solid #d73128;
}

/* Navbar adjustments */
.navbar-nav {
    display: flex;
    justify-content: center;
    width: 100%;
}

.navbar-nav > li {
    margin: 0 30px;
}

/* Responsiveness */
@media (max-width: 768px) {
    .navbar-nav {
        flex-direction: column;
        margin-top: 10px;
    }
    .col-md-4 {
        text-align: center;
    }
}
</style>
