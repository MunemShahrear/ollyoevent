




     
    <!--footer wraper-->
 
    <footer class="bg-dark text-white py-4" >
    <div class="container-fluid">
        <div class="row">
        <div class="col-md-6 text-center">
                           <a href="index.php">
                               
                               <p style="font-family: 'Russo One', sans-serif; font-size: 25px; color: #FFF;">Event Management</p>
                           </a>
                       </div>
           
           
            <div class="col-md-6">
                <h5 class="text-white">Contact</h5>
                <ul class="list-unstyled">
                    <li>123 Street Name, City</li>
                    <li>Phone: +1234567890</li>
                    <li>Email: example@example.com</li>
                </ul>
            </div>
        </div>
        <hr class="mt-4 mb-3">
      
    </div>
</footer>

<div class="bg-dark text-white py-3 text-center">
    &copy; 2025 All rights reserved by <a href="https://www.imhimel.com" target="_blank">Munem Shahrear.</a>
</div>