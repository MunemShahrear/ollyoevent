<?php
session_start();
include("../database/db.php");
include('../function/functions.php');
$currentDate = date("Y");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<link rel="stylesheet" href="../style/style.css"> <!-- You can keep your custom styles -->
</head>
<body>

<div class="container">
<a href="../login/logout.php" class="float-right mt-3 mr-3"><button class="btn btn-warning"><i class="fas fa-user"></i> Logout</button></a>

    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="header_wraper mt-4">
            </div>

            <div class="content_wraper mt-4">

                <div class="text-center mb-4">
                    <h2>Admin Option</h2>
                </div>

                <div class="text-center">
                <a href="manage_reservation.php" class="btn btn-success btn-lg btn-block">
                        <i class="fas fa-ticket-alt mr-2"></i> Manage Reservation
                    </a><br>
                
                <a href="insert_event.php" class="btn btn-primary btn-lg btn-block">
                        <i class="fas fa-plus-circle mr-2"></i> Insert New Event
                    </a>
                    <br>
                    <a href="update_page.php" class="btn btn-secondary btn-lg btn-block">
                        <i class="fas fa-edit mr-2"></i> Update Event
                    </a>
                    <br>
                    <a href="delete_product.php" class="btn btn-danger btn-lg btn-block">
                        <i class="fas fa-trash-alt mr-2"></i> Delete Event
                    </a>
                </div>

            </div>

            

        </div>
    </div>

</div>

</body>
</html>
