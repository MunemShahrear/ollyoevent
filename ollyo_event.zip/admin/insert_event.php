<?php
include("../database/db.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin - Add Event</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<link rel="stylesheet" href="../style/style.css"> 
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="header_wraper mt-4">
                <a href="admin_option.php" class="float-right mt-3 mr-3">
                    <button class="btn btn-warning"><i class="fas fa-arrow-left"></i> Back</button>
                </a>
            </div>

            <div class="content_wraper mt-4">
                <form method="post" action="insert_event.php" enctype="multipart/form-data">
                    <table class="table table-bordered">
                        <tr align="center">
                            <td colspan="2"><strong>Add New Event</strong></td>
                        </tr>
                        <tr>
                            <td align="right"><b>Event Title :</b></td>
                            <td><input type="text" class="form-control" name="event_title" required></td>
                        </tr>
                        <tr>
                            <td align="right"><b>Category :</b></td>
                            <td>
                                <select name="event_category" class="form-control" required>
                                    <option value="">Select a category</option>
                                    <?php
                                    $get_cats = "SELECT * FROM categories";
                                    $run_cats = mysqli_query($db, $get_cats);
                                    while ($row_cats = mysqli_fetch_array($run_cats)) {
                                        echo "<option value='{$row_cats['cat_id']}'>{$row_cats['cat_title']}</option>";
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td align="right"><b>Date :</b></td>
                            <td><input type="date" class="form-control" name="event_date" required></td>
                        </tr>
                        <tr>
                            <td align="right"><b>Time:</b></td>
                            <td><input type="time" class="form-control" name="event_time" required></td>
                        </tr>
                        <tr>
                            <td align="right"><b>Seats Available :</b></td>
                            <td><input type="number" class="form-control" name="seats" min="1" required></td>
                        </tr>
                        <tr>
                            <td align="right"><b>Event Banner :</b></td>
                            <td><input type="file" name="event_banner" class="form-control-file" required></td>
                        </tr>
                        <tr>
                        <td align="right"><b>Event Venue :</b></td>
                        <td><input type="text" class="form-control" name="event_venue" required></td>
                        </tr>
                        <tr>
                            <td align="right"><b>Price (if applicable) :</b></td>
                            <td><input type="text" name="event_price" class="form-control"></td>
                        </tr>
                        <tr>
                            <td align="right"><b>Description :</b></td>
                            <td><textarea name="event_desc" class="form-control" rows="5" required></textarea></td>
                        </tr>
                        <tr>
                            <td align="right"><b>Keywords :</b></td>
                            <td><input type="text" name="event_keywords" class="form-control" required></td>
                        </tr>
                        <tr>
                            <td colspan="2" align="center">
                                <input type="submit" name="insert_event" value="Add Event" class="btn btn-primary">
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>
</div>

</body>
</html>

<?php 
if (isset($_POST['insert_event'])) {
    $event_title = mysqli_real_escape_string($db, $_POST['event_title']);
    $event_category = $_POST['event_category'];
    $event_date = $_POST['event_date'];
    $event_time = $_POST['event_time'];
    $seats = $_POST['seats'];
    $event_venue = $_POST['event_venue'];
    $event_price = !empty($_POST['event_price']) ? $_POST['event_price'] : 'Free';
    $event_desc = mysqli_real_escape_string($db, $_POST['event_desc']);
    $event_keywords = mysqli_real_escape_string($db, $_POST['event_keywords']);

    $event_banner = $_FILES['event_banner']['name'];
  

    $temp_banner = $_FILES['event_banner']['tmp_name'];
  

    if (empty($event_title) || empty($event_category) || empty($event_date) || empty($event_time) || empty($event_desc) || empty($event_keywords) || empty($event_banner)) {
        echo "<script>alert('Please fill in all required fields!')</script>";
        exit();
    } else {
        move_uploaded_file($temp_banner, "event_images/$event_banner");
        

        $insert_event = "INSERT INTO events (cat_id, event_date, event_time, title, description, price, banner, event_venue, keywords, seats, created_at) 
            VALUES ('$event_category', '$event_date', '$event_time', '$event_title', '$event_desc', '$event_price', '$event_banner', '$event_venue', '$event_keywords', '$seats', NOW())";
        
        $run_event = mysqli_query($db, $insert_event);

        if ($run_event) {
            echo "<script>alert('Event added successfully!')</script>";
          
        } else {
            echo "<script>alert('Event insertion failed!')</script>";
        }
    }
}
?>
