<?php
session_start();
include("../database/db.php");
include('../function/functions.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin</title>
<link rel="stylesheet" href="../style/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">

            <div class="header_wraper">
            <a href="admin_option.php" class="float-right mt-3 mr-3"><button class="btn btn-warning"><i class="fas fa-arrow-left"></i> Back</button></a>

            </div>

            <div class="content_wraper mt-4">
                <div class="h1">Update Products</div>
                <div id="headline2"></div>

                <div id="del_page" class="row">
				<?php getupdate(); ?>
                </div>
            </div>

            

        </div>
    </div>
</div>
<a href="admin_option.php" class="float-right mt-3 mr-3"><button class="btn btn-warning"><i class="fas fa-arrow-left"></i> Back</button></a>

</body>
</html>
