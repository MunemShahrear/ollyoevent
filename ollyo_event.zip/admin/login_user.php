<?php
session_start();
$host = "localhost"; 
$username = "root"; 
$password = ""; 
$db_name = "event_management"; 

$conn = new mysqli($host, $username, $password, $db_name);

$myusername = $_POST['name']; 
$mypassword = $_POST['password']; 

if (empty($myusername) || empty($mypassword)) {
    echo "<script>alert('Please fill in all fields.')</script>";
    exit();
}

$sql = "SELECT * FROM user_table WHERE `user_email`='$myusername' AND `user_pass`='$mypassword'";
$result = $conn->query($sql);
$count = $result->num_rows;

if ($count == 1) {
    $row = $result->fetch_assoc();
    $_SESSION["IdValidation"] = $myusername;
    $_SESSION["UserId"] = $row['id'];  
    
    header('Location: ../payment.php');
} else {
    $_SESSION["error"] = "Wrong Username or Password";
    echo "<script>alert('Wrong Username or Password.')</script>";
}
?>
