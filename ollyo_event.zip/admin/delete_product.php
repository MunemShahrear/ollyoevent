<?php
session_start();
include("../database/db.php");
include('../function/functions.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="../style/style.css"> <!-- You can keep your custom styles -->
</head>

<body>

    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-12">

                <div class="header_wraper mt-4">
                    <a href="admin_option.php" class="float-right mt-3 mr-3"><button class="btn btn-warning"><i
                                class="fas fa-arrow-left"></i> Back</button></a>

                </div>

                <div class="content_wraper mt-4">
                    <div class="text-center">
                        <h2>Delete Products</h2>
                    </div>
                    <div class="row mt-4">
                        <?php 
                        getdel();
                        ?>
                    </div>
                </div>


            </div>
        </div>

    </div>
    <a href="admin_option.php" class="float-right mt-3 mr-3"><button class="btn btn-warning"><i
                class="fas fa-arrow-left"></i> Back</button></a>

</body>

</html>
<?php
// Make sure there's no whitespace or HTML content before this opening PHP tag
if (isset($_POST['product_id'])) {
    // Get the product ID from the form submission
    $product_id = $_POST['product_id'];

    // Connect to your database
  

    // Check connection
    if ($db->connect_error) {
        die("Connection failed: " . $db->connect_error);
    }

    // Prepare and execute the SQL statement to delete the product
    $sql = "DELETE FROM events WHERE id = $product_id";

    if ($db->query($sql) === TRUE) {
        // Product deleted successfully
        // Redirect to admin_option.php
        echo "item Deleted" .
        exit; // Make sure to stop execution after redirection
    } else {
        // Error deleting product
        echo "Error deleting item: " . $db->error;
    }

    // Close the database connection
    $db->close();
}
?>