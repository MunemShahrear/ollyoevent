<?php
// Database connection
$db = mysqli_connect("localhost", "cnzixezfln_event_management", "Himel625646@#", "cnzixezfln_event_management");

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

// Update status if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id']) && isset($_POST['status'])) {
    $order_id = intval($_POST['order_id']);
    $status = intval($_POST['status']);

    // Start transaction for data integrity
    mysqli_begin_transaction($db);

    try {
        // Fetch the event_id and qty for this order
        $fetch_query = "SELECT event_id, qty FROM order_confirmed WHERE order_id = ?";
        $stmt_fetch = $db->prepare($fetch_query);
        $stmt_fetch->bind_param("i", $order_id);
        $stmt_fetch->execute();
        $stmt_fetch->bind_result($event_id, $qty);
        $stmt_fetch->fetch();
        $stmt_fetch->close();

        // Update order status
        $update_query = "UPDATE order_confirmed SET Status = ? WHERE order_id = ?";
        $stmt = $db->prepare($update_query);
        $stmt->bind_param("ii", $status, $order_id);

        if (!$stmt->execute()) {
            throw new Exception("Error updating order status: " . $stmt->error);
        }
        $stmt->close();

        // If order is accepted, deduct the qty from event seats
        if ($status == 1) {
            $update_seats_query = "UPDATE events SET seats = seats - ? WHERE id = ? AND seats >= ?";
            $stmt_seats = $db->prepare($update_seats_query);
            $stmt_seats->bind_param("iii", $qty, $event_id, $qty);

            if (!$stmt_seats->execute()) {
                throw new Exception("Error updating event seats: " . $stmt_seats->error);
            }

            // Check if any rows were affected (to ensure seats were updated)
            if ($stmt_seats->affected_rows === 0) {
                throw new Exception("Not enough available seats for this event.");
            }

            $stmt_seats->close();
        }

        // Commit transaction if everything is successful
        mysqli_commit($db);
        echo '<div class="alert alert-success">Order status updated successfully.</div>';
    } catch (Exception $e) {
        // Rollback transaction in case of error
        mysqli_rollback($db);
        echo '<div class="alert alert-danger">' . $e->getMessage() . '</div>';
    }
}

// Fetch data from the order_confirmed table
$query = "
    SELECT 
        order_confirmed.*, events.title, events.event_date, events.event_venue, events.seats
    FROM 
        order_confirmed
    INNER JOIN 
        events ON order_confirmed.event_id = events.id
";

$result = mysqli_query($db, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($db));
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Reservations</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .table-responsive {
            margin-top: 20px;
        }
        .btn-action {
            margin-right: 5px;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header_wrapper mt-4">
        <a href="admin_option.php" class="float-right mt-3 mr-3">
            <button class="btn btn-warning"><i class="fas fa-arrow-left"></i> Back</button>
        </a>
    </div><br>

    <h1 class="mt-5">Manage Reservations</h1>

    <div class="table-responsive">
    <a href="export_excel.php" class="btn btn-success mb-3">
    <i class="fas fa-download"></i> Download Excel
</a>
        <table class="table table-striped table-hover">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">Event Details</th>
                    <th scope="col">Booking User Name</th>
                    <th scope="col">Date for Booking</th>
                    <th scope="col">Venue</th>
                    <th scope="col">Seats</th>
                    <th scope="col">Total</th>
                    <th scope="col">Status</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $status = $row["Status"];
                        $user_id = $row["user_id"];

                        // Fetch user details
                        $sql = $db->prepare("SELECT user_name, user_email FROM user_table WHERE id = ?");
                        $sql->bind_param("i", $user_id);
                        $sql->execute();
                        $sql->bind_result($user_name, $user_email);
                        $user_data_fetched = $sql->fetch();
                        $sql->close();

                        // If user data is not found, provide fallback values
                        if (!$user_data_fetched) {
                            $user_name = "Unknown User";
                            $user_email = "N/A";
                        }

                        // Button disable logic
                        $buttonDisabled = $status != 0 ? "disabled" : "";

                        // Status text
                        $statusText = $status == 0 ? "Pending" : ($status == 1 ? "Accepted" : "Cancelled");

                        echo '<tr>
                                <td>' . htmlspecialchars($row["title"]) . '</td>
                                <td>' . htmlspecialchars($user_name) . '</td>
                                <td>' . htmlspecialchars($row["event_date"]) . '</td>
                                <td>' . htmlspecialchars($row["event_venue"]) . '</td>
                                <td>' . htmlspecialchars($row["qty"]) . '</td>
                                <td>' . htmlspecialchars($row["total"]) . '</td>
                                <td>' . $statusText . '</td>
                                <td>
                                    <form method="POST" style="display:inline-block;">
                                        <input type="hidden" name="order_id" value="' . $row["order_id"] . '">
                                        <input type="hidden" name="status" value="1">
                                        <button type="submit" class="btn btn-success btn-sm" ' . $buttonDisabled . '>Accept</button>
                                    </form>
                                    <form method="POST" style="display:inline-block;">
                                        <input type="hidden" name="order_id" value="' . $row["order_id"] . '">
                                        <input type="hidden" name="status" value="2">
                                        <button type="submit" class="btn btn-danger btn-sm" ' . $buttonDisabled . '>Cancel</button>
                                    </form>
                                </td>
                            </tr>';
                    }
                } else {
                    echo "<tr><td colspan='8'>No reservations found</td></tr>";
                }

                mysqli_close($db);
                ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Bootstrap JS, Popper.js, and jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
