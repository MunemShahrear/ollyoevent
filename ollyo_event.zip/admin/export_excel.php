<?php
// Database connection
$db = mysqli_connect("localhost", "cnzixezfln_event_management", "Himel625646@#", "cnzixezfln_event_management");

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

// Set headers to force download
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=participants_list.xls");
header("Pragma: no-cache");
header("Expires: 0");

// Start output buffer
echo "Event Title\tUser Name\tEmail\tDate for Booking\tVenue\tSeats\tTotal\tStatus\n";

// Fetch data
$query = "
    SELECT 
        order_confirmed.*, events.title, events.event_date, events.event_venue, user_table.user_name, user_table.user_email
    FROM 
        order_confirmed
    INNER JOIN 
        events ON order_confirmed.event_id = events.id
    INNER JOIN
        user_table ON order_confirmed.user_id = user_table.id
";

$result = mysqli_query($db, $query);

if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $statusText = $row["Status"] == 0 ? "Pending" : ($row["Status"] == 1 ? "Accepted" : "Cancelled");

        echo htmlspecialchars($row["title"]) . "\t" .
             htmlspecialchars($row["user_name"]) . "\t" .
             htmlspecialchars($row["user_email"]) . "\t" .
             htmlspecialchars($row["event_date"]) . "\t" .
             htmlspecialchars($row["event_venue"]) . "\t" .
             htmlspecialchars($row["qty"]) . "\t" .
             htmlspecialchars($row["total"]) . "\t" .
             $statusText . "\n";
    }
}

mysqli_close($db);
exit();
?>