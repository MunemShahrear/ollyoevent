<?php
// Database connection
$db = mysqli_connect("localhost", "cnzixezfln_event_management", "Himel625646@#", "cnzixezfln_event_management");

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['order_id']);
    $status = intval($_POST['status']);

    $query = "UPDATE order_confirmed SET Status = ? WHERE id = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param("ii", $status, $id);

    if ($stmt->execute()) {
        echo 'success';
    } else {
        echo 'error';
    }

    $stmt->close();
}

$db->close();
?>