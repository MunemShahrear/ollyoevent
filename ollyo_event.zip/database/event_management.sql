-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2025 at 03:03 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `event_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_table`
--

CREATE TABLE `admin_table` (
  `id` int(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin_table`
--

INSERT INTO `admin_table` (`id`, `user_email`, `password`, `name`) VALUES
(2, 'admin@admin.com', 'admin', 'Himel');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(40) NOT NULL,
  `event_id` int(40) NOT NULL,
  `qty` int(40) NOT NULL,
  `total_price` int(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `event_id`, `qty`, `total_price`) VALUES
(148, 1, 1, 500);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(50) NOT NULL,
  `cat_title` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(10, 'Conference'),
(11, 'Seminar'),
(12, 'Trade Show'),
(13, 'Networking'),
(14, 'Product Launch'),
(15, 'Private Event'),
(16, 'Company Party'),
(17, 'Festival'),
(18, 'Team Building');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `event_date` date NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `banner` varchar(255) NOT NULL,
  `event_time` time DEFAULT NULL,
  `event_venue` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `seats` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `cat_id`, `event_date`, `title`, `description`, `price`, `banner`, `event_time`, `event_venue`, `keywords`, `seats`, `created_at`) VALUES
(1, 10, '2025-02-26', 'Music', 'asaa', 500.00, '4b924325613089a96886f1f64ce6d657.jpg', '15:20:00', 'mirpur', 'music', 195, '2025-01-31 18:21:40'),
(2, 15, '2025-03-05', 'Concert', 'Concert , band, Guiter', 0.00, '4b924325613089a96886f1f64ce6d657.jpg', '00:27:00', 'Dhaka', 'asdads', 0, '2025-02-01 10:49:05'),
(3, 10, '2025-02-19', 'Corporate', 'Corporate event', 200.00, '4-education-box-challenge-thumb.jpg', '16:45:00', 'brunai', 'Corporate event', 10, '2025-02-01 08:43:17'),
(4, 14, '2025-02-28', 'Maxhub', 'All IT managers', 0.00, 'colorful-conference-presentation-modern-bold-1-1-94a8e197aea7.webp', '19:26:00', 'Gulshan , Lakeshore Heights', 'IT event', 100, '2025-02-01 09:25:43');

-- --------------------------------------------------------

--
-- Table structure for table `order_confirmed`
--

CREATE TABLE `order_confirmed` (
  `order_id` int(20) NOT NULL,
  `adress` varchar(50) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `Status` varchar(255) NOT NULL,
  `event_id` int(20) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `user_id` int(20) NOT NULL,
  `license` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `order_confirmed`
--

INSERT INTO `order_confirmed` (`order_id`, `adress`, `mobile`, `name`, `Status`, `event_id`, `qty`, `total`, `user_id`, `license`) VALUES
(28, 'House-23, Road no -6, Block -D, Niketon, Dhaka', '1644930269', 'Md Munem Shahrear Himel', '1', 3, '2', '400', 7, '1231231231'),
(29, 'House-23, Road no -6, Block -D, Niketon, Dhaka', '1644930269', 'Md Munem Shahrear Himel', '1', 4, '2', '0', 7, '2852691449'),
(30, 'House-23, Road no -6, Block -D, Niketon, Dhaka', '1644930269', 'Md Munem Shahrear Himel', '1', 1, '4', '2000', 7, '34242243'),
(31, 'House-23, Road no -6, Block -D, Niketon, Dhaka', '342', 'Md Munem Shahrear Himel', '1', 1, '5', '2500', 7, '23423423'),
(33, 'House-23, Road no -6, Block -D, Niketon, Dhaka', '3242423', 'Md Munem Shahrear Himel', '0', 1, '2', '1000', 13, '23423423');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `id` int(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_pass` varchar(50) NOT NULL,
  `user_pic` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`id`, `user_name`, `user_email`, `user_pass`, `user_pic`) VALUES
(7, 'user', 'user@user.com', 'user', ''),
(8, 'Md Munem Shahrear', 'himel@gmail.com', '$2y$10$D4NVnXC1Oo7.P3xLl8fXZOPw/PY5YrLQxgNWXnA0L01', ''),
(11, 'Himel', 'test2@gmail.com', '$2y$10$QmhzM25QNz2ifnvSFKNowOfWYSFzeGcNkw8C1OQJM2y', ''),
(12, 'test3', 'test@test.com', '$2y$10$RlQHFuRStJgHPJxZlUy66ObWgkGiUfGlOIMczwuu2OZ', ''),
(13, 'kkk', 'kkk@kkk.com', 'kkk', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_table`
--
ALTER TABLE `admin_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_confirmed`
--
ALTER TABLE `order_confirmed`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_table`
--
ALTER TABLE `admin_table`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=149;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_confirmed`
--
ALTER TABLE `order_confirmed`
  MODIFY `order_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
